import React, { Component } from 'react';

class Footer extends Component {

    render() {
        return (
            <p>Alexis OUKSEL / Nicolas VINCENT</p>
        );
    }
}


export default Footer; 